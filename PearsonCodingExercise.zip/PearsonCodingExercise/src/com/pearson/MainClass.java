package com.pearson;

import java.io.Console;


public class MainClass {

	public static void main(String[] args) {

		Converter converter = new Converter();
		
		Console c = System.console();

		if (c == null) {
			System.err.println("No console.");
			System.exit(1);
		}
		
		while (true) {
			System.out.print(">");
			String input = c.readLine();

			if (input.equalsIgnoreCase("exit")) {
				System.exit(0);
			}else{
				try{
					int digits = Integer.parseInt(input);
					System.out.println(converter.convert(digits));
				}catch(Exception e){
					System.out.println("Only numeric value expected, to quit type EXIT");
				}
			}
		}
		
		
	}

	/* (non-Java-doc)
	 * @see java.lang.Object#Object()
	 */
	public MainClass() {
		super();
	}
	
	
}
