package com.pearson;


import java.util.ArrayList;
import java.util.List;
import java.util.*;

	public class Converter {
		
		static private String [] units;
		static private String [] tens;


		static{
			units = new String[]{"zero","one","two","three","four","five","six","seven","eight","nine","ten",
								 "eleven","twelve","thirteen","fourteen","fifteen","sixteen","seventeen","eighteen","Nineteen"};
			
			tens = new String[]{"","ten","twenty","thirty","forty","fifty","sixty","seventy","eighty","ninety"};
			
		}
		
		public String convert(int number){
			
			List<Integer> digits = getDigits(number);
			return getWords(digits);
			
		}
		
		/*
		 * converts a int to a List<Integer>
		 */
	    protected List<Integer> getDigits(int number) {
	        
	    	ArrayList<Integer> digits = new ArrayList<Integer>();
	        
	    	if (number == 0) {
	            digits.add(0);
	        } else {
	        	// this will get the last digit one by one
	            while (number > 0) { 
	                digits.add(0, (int) number % 10);
	                number /= 10;
	            }
	        }
	        return digits;
	    
	    }
	    
	    /*
	     * Recursive method for converting a number
	     * represented by a List<Integer> to words in English
	     */
	    protected String getWords(List<Integer> digits){
	    	
	    	String words = ""; 

	    	if (digits.size() > 6){
	    		
	    		//Get value below Million
	    		words = getWords(digits.subList(digits.size()-6,digits.size()));
	    		//Get value above Million and concatenate
	    		words = getWords(digits.subList(0,digits.size()-6)) + " million " + words;
	    	
	    	}else if (digits.size()>3){

	    		//Get value above Thousands
	    		words = getWords(digits.subList(0,digits.size()-3));
	    		
	    		//Manage AND for the special case when thousands come as blank
	    		if (words != "")
	    			words = words + " thousand ";
	    		else
	    			words = "and ";
	    		//Get value below Thousands and concatenate
	    		words = words + getWords(digits.subList(digits.size()-3,digits.size()));
	    		
	    		
	    	}else{
		    	
	    		int i = 0;
		    	int unit = 0;
		    	int length = digits.size(); 
		    	boolean andSet = true;
		    	
		    	while (i < length){
		    	
		    		int digit = digits.get(length - 1 - i);
		    		
		    		if (digit != 0){
			    		if(i == 0){
			    			 unit = digit; 	
			    			 words = units[digit];
			    			 andSet = false;
			    		}else if (i == 1){
			    			if (digit == 1){
			    				words = units[10+unit];
			    			}else{
			    				words = tens[digit] + " " + words;
			    			}
			    			 andSet = false;
			    		}else if (i==2){
			    			
			    			words = units[digit] + " hundred " + (!andSet?"and ":"") + words;
			    		}
		    		}
		    		
		    		i++;
		    	}

	    	}    
	    	return words;
	    }
}
